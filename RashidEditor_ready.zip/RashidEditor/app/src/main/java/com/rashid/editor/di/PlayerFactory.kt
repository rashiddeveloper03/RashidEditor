package com.rashid.editor.di

import android.content.Context
import androidx.media3.exoplayer.ExoPlayer
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

/** Har editor session ko apna ExoPlayer milta hai (singleton nahi). */
class PlayerFactory @Inject constructor(
    @ApplicationContext private val ctx: Context
) {
    fun create(): ExoPlayer = ExoPlayer.Builder(ctx).build()
}
