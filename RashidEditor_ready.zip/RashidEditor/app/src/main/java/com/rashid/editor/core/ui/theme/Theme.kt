package com.rashid.editor.core.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0E0F13)
val Surface1 = Color(0xFF171920)
val Surface2 = Color(0xFF20232C)
val Accent = Color(0xFF7C5CFF)
val AccentSoft = Color(0xFFB3A1FF)
val TextHigh = Color(0xFFF2F3F7)
val TextLow = Color(0xFF9AA0AE)

private val RashidDark = darkColorScheme(
    primary = Accent,
    onPrimary = Color.White,
    secondary = AccentSoft,
    background = Bg,
    onBackground = TextHigh,
    surface = Surface1,
    onSurface = TextHigh,
    surfaceVariant = Surface2,
    onSurfaceVariant = TextLow
)

@Composable
fun RashidTheme(content: @Composable () -> Unit) {
    // Dark theme first. Light theme baad mein add hogi.
    MaterialTheme(colorScheme = RashidDark, typography = Typography(), content = content)
}
