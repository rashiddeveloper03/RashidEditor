package com.rashid.editor.domain.model

import android.net.Uri

/** Non-destructive model: original file kabhi change nahi hoti, sirf in/out points badalte hain. */
data class VideoClip(
    val id: String,
    val uri: Uri,
    val durationMs: Long,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = durationMs
)
