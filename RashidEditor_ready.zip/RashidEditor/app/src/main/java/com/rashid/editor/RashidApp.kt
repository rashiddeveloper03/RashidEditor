package com.rashid.editor

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class RashidApp : Application()
