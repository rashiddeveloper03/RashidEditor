package com.rashid.editor.editor

import android.app.Application
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rashid.editor.di.PlayerFactory
import com.rashid.editor.domain.model.VideoClip
import com.rashid.editor.player.PlayerController
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID
import javax.inject.Inject

data class EditorUiState(val clips: List<VideoClip> = emptyList())

@HiltViewModel
class EditorViewModel @Inject constructor(
    private val app: Application,
    playerFactory: PlayerFactory
) : AndroidViewModel(app) {

    val controller = PlayerController(playerFactory.create())

    private val _ui = MutableStateFlow(EditorUiState())
    val ui: StateFlow<EditorUiState> = _ui.asStateFlow()

    fun onVideosPicked(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val newClips = withContext(Dispatchers.IO) {
                uris.mapNotNull { uri ->
                    runCatching {
                        val mmr = MediaMetadataRetriever()
                        try {
                            mmr.setDataSource(app, uri)
                            val dur = mmr.extractMetadata(
                                MediaMetadataRetriever.METADATA_KEY_DURATION
                            )?.toLongOrNull() ?: 0L
                            VideoClip(UUID.randomUUID().toString(), uri, dur)
                        } finally { mmr.release() }
                    }.getOrNull()
                }
            }
            val all = _ui.value.clips + newClips
            _ui.value = EditorUiState(all)
            controller.setClips(all)
        }
    }

    override fun onCleared() {
        controller.release()
        super.onCleared()
    }
}
