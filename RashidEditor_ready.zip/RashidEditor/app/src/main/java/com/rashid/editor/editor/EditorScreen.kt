package com.rashid.editor.editor

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import com.rashid.editor.R
import com.rashid.editor.core.ui.theme.*
import kotlinx.coroutines.delay

@OptIn(UnstableApi::class)
@Composable
fun EditorScreen(vm: EditorViewModel = hiltViewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val ps by vm.controller.state.collectAsStateWithLifecycle()

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(maxItems = 20)
    ) { uris -> vm.onVideosPicked(uris) }

    val pickVideo = {
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
    }

    LaunchedEffect(ps.isPlaying) {
        while (ps.isPlaying) { vm.controller.publish(); delay(33) }
    }

    Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding()) {

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.app_name), style = MaterialTheme.typography.titleMedium)
                Text(
                    stringResource(R.string.tagline),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            FilledTonalButton(onClick = { pickVideo() }) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(4.dp))
                Text(stringResource(R.string.add_clip))
            }
        }

        Box(
            Modifier.fillMaxWidth().weight(1f).background(Surface1),
            contentAlignment = Alignment.Center
        ) {
            if (ui.clips.isEmpty()) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.VideoLibrary, null, tint = TextLow, modifier = Modifier.size(56.dp))
                    Spacer(Modifier.height(8.dp))
                    Text(stringResource(R.string.no_video), color = TextLow)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { pickVideo() }) { Text(stringResource(R.string.import_video)) }
                }
            } else {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            useController = false
                            player = vm.controller.player
                        }
                    }
                )
            }
        }

        if (ui.clips.isNotEmpty()) {
            Column(Modifier.padding(horizontal = 16.dp)) {
                val dur = ps.durationMs.coerceAtLeast(1L).toFloat()
                Slider(
                    value = ps.positionMs.toFloat().coerceIn(0f, dur),
                    onValueChange = { vm.controller.seekTo(it.toLong()) },
                    valueRange = 0f..dur
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "${fmt(ps.positionMs)} / ${fmt(ps.durationMs)}",
                        style = MaterialTheme.typography.bodySmall, color = TextLow
                    )
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { vm.controller.togglePlay() }) {
                        Icon(
                            if (ps.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = null, tint = Accent,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                    Spacer(Modifier.weight(1f))
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().background(Surface1)
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 8.dp, horizontal = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            ToolItem(Icons.Default.ContentCut, stringResource(R.string.tool_trim))
            ToolItem(Icons.Default.AutoAwesome, stringResource(R.string.tool_filters))
            ToolItem(Icons.Default.MusicNote, stringResource(R.string.tool_audio))
            ToolItem(Icons.Default.TextFields, stringResource(R.string.tool_text))
            ToolItem(Icons.Default.IosShare, stringResource(R.string.tool_export))
        }
    }
}

@Composable
private fun ToolItem(icon: ImageVector, label: String) {
    Column(
        Modifier.width(72.dp).padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = TextHigh)
        Text(label, style = MaterialTheme.typography.labelSmall, color = TextLow)
    }
}

private fun fmt(ms: Long): String {
    val s = ms / 1000
    return "%02d:%02d".format(s / 60, s % 60)
}
