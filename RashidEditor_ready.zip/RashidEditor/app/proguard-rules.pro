# Phase 1: koi custom rule nahi.
